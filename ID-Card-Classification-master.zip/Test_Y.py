import tensorflow as tf
import dataset
import numpy as np
import os
import glob
import PIL

def load_test1(test_path, image_size, classes):

    X_test = []
    X_test_id = []

    for class_name in classes:
        path = os.path.join(test_path,class_name, '*g')
        files = sorted(glob.glob(path))


        print("Reading test images")
        for fl in files:
            flbase = os.path.basename(fl)
            print(fl)
            img = PIL.Image.open(fl)
            image = img.resize((image_size, image_size))
            X_test.append(np.array(image))
            X_test_id.append(flbase)

  ### because we're not creating a DataSet object for the test images, normalization happens here
    X_test = np.array(X_test, dtype=np.uint8)
    X_test = X_test.astype('float32')
    X_test = X_test / 255

    #print(X_test.size)

    return X_test, X_test_id


sess = tf.Session()
saver = tf.train.import_meta_graph('pk_test_model.meta')
saver.restore(sess, tf.train.latest_checkpoint('./'))
graph = tf.get_default_graph()

y_pred = graph.get_tensor_by_name("y_pred:0")

#your test path
test_path='.\\test'

img_size = 128

#more than one class can be added according to your requirement
#classes = ['sig1', 'sig2']
classes = ['California', 'NewJersey']
num_classes = len(classes)

#num_channels is the number of test images in the test folder
num_channels = 3
img_size_flat = img_size * img_size * 3
test_images, test_ids = load_test1(test_path, img_size, classes)

print("done" )
print(test_ids)

x= graph.get_tensor_by_name("x:0")
x_batch = test_images.reshape(3, img_size_flat)
y_true = graph.get_tensor_by_name("y_true:0")
y_test_images = np.zeros((num_channels, 2))
feed_dict_testing = {x: x_batch, y_true: y_test_images}
print(sess.run(y_pred, feed_dict=feed_dict_testing))

