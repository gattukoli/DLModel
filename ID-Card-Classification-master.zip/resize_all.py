from PIL import Image
import os


test_path = ".\\test\\California\\"
imgsize = 128

for fl in os.listdir(test_path):
    path = os.path.join(test_path, fl)
    print(path)
    im_gs = Image.open(path)
    im_gs = im_gs.resize((imgsize, imgsize))
    im_gs.save(path)

print("Done")


# Read image
# Deskew, Shear removal
# crop
# save
